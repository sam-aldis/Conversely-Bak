window.$ = window.jQuery = require('jquery');
$( document ).ready(function() {
      $(".sidebar-button").sideNav();
});