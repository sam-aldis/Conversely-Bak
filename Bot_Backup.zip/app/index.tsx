import * as ReactDOM from "react-dom";
import * as React from "react";
import {Navbar, Icon, Row, Input, Col, Card, CardPanel, CardTitle, SideNav, SideNavItem, NavItem, Chip, Button, Footer, Modal}  from 'react-materialize';
import FacebookLogin from 'react-facebook-login';
import * as $ from "jquery";

class Application extends React.Component<any,any> {
        constructor() {
                super();
                this.state = {
                        loggedIn : false
                }
        }
        public facebookResponse(res) {

        }
        render() {
                if(this.state.loggedIn) {
                        return <div>
                                        <SideNav trigger={<div className="menu-button"><Icon>menu</Icon></div>}
                                        options={{ draggable: true }}
                                        className="showOnLarge fixed side-nav">
                                                <SideNavItem userView user={{
                                                        image : "http://www.ukjp-design.com/img/4.png",
                                                        background : "img/blackBg.png",
                                                        name : "UKJP-Design",
                                                }} />
                                                <SideNavItem href="#" waves icon="home">Home</SideNavItem>
                                                <SideNavItem href="#" waves icon="track_changes">Radar</SideNavItem>
                                                <SideNavItem href="#" waves icon="work">Campaigns</SideNavItem>
                                                <SideNavItem href="#" waves icon="forum">Conversations</SideNavItem>
                                                <SideNavItem href="#" waves icon="contacts">Contacts</SideNavItem>
                                                <SideNavItem href="#" waves icon="extension">Intergrations</SideNavItem>
                                                <br />
                                                <br />
                                                <br />
                                                <div className="menu-bottom">
                                                        <hr />
                                                        <SideNavItem href="#" waves icon="settings">Settings</SideNavItem>
                                                        <SideNavItem href="#" waves icon="help">Help</SideNavItem>
                                                        <SideNavItem href="#" waves icon="bug_report">Bug Report</SideNavItem>
                                                </div>
                                        </SideNav>
                                        <div className="main">
                                                <Row>
                                                        <Col m={6} s={12}>
                                                                <Card title="Getting Started" actions={[<a href="#">Next</a>]}>
                                                                        Welcome!
                                                                        <br />Lets get started straight away by creating your
                                                                        <br />very first bot. This will instantly be linked
                                                                        <br />to your Facebook Page Account and you will be
                                                                        <br />able to start putting it through its paces
                                                                        <br />right away!
                                                                </Card>
                                                        </Col>
                                                </Row>
                                        </div>
                                </div>;
                } else {
                        return <div>
                                        <Navbar brand={<span><Icon className="headerText">record_voice_over</Icon>Conversely</span>} right>
                                                <NavItem href="/about">About</NavItem>
                                                <NavItem href="/login">Login</NavItem>
                                        </Navbar>
                                        <Row className="preLoginContent">
                                                        <Row>  
                                                                <Col s={12} className="signupBox">
                                                                        <Col s={12} m={6} offset="m3">
                                                                                <Card title="Get Started"
                                                                                        actions={[<FacebookLogin
                                                                                        appId="1687304584632919"
                                                                                        autoLoad={true}
                                                                                        fields="name,email,picture"
                                                                                        callback={this.facebookResponse}
                                                                                        cssClass="btn waves-effect waves-light btnFacebook"
                                                                                        icon="fa-facebook" />]} >
                                                                                        Create your first bot in 2 minutes.
                                                                                        <br />No credit card details required.
                                                                                </Card>
                                                                        </Col>
                                                                </Col>
                                                        </Row>
                                                      
                                        </Row>
                                        <Row className="preLoginTopArea">
                                                              <Col s={12} m={4}>
                                                              <Card actions={[<Modal
  header='Modal Header'
  fixedFooter
  trigger={
    <a href='#'>Learn More</a>
  }>
  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum
</Modal>]}>
                                                                <Icon>speaker_notes_off</Icon>
                                                                <br />
                                                                There are currently 34,000+ Facebook bots using the platform however most of these provide a very poor user experience and are unable to understand even the most basic of user messages
                                                                </Card>
                                                              </Col>
                                                              <Col s={12} m={4}>
                                                              <Card actions={[<a href="#learn_more">Learn More</a>]}>
                                                                <Icon>filter_drama</Icon>
                                                                <br />
                                                                We have created a Platform from which you can release intelligent and self learning bots.
                                                                This means your bot will get smarter the more it is used, more able to interact with your
                                                                clients and provide a more human experience. 
                                                                </Card>
                                                              </Col>
                                                              <Col s={12} m={4}>
                                                              <Card actions={[<a href="#learn_more">Learn More</a>]}>
                                                              <Icon>school</Icon>
                                                              <br />
                                                              You set your goals, targets and other important information about your business and the bot will attempt to understand
                                                              what your users are asking of it. If it can't understand it will pass it on to you and learn from the response you give.
                                                              </Card>
                                                              </Col>
                                        </Row>
                                        <Row className="extraInfo">
                                                                <Col s={12} m={12}>
                                                                        <Row>
                                                                                <Col s={0} m={1}>
                                                                                </Col>
                                                                                <Col s={12} m={10}>
                                                                                        <br /><Icon>track_changes</Icon>
                                                                                        <br />We provide an easy to use CRM software for our bots, 
                                                                                        It will track all of your page users and how they are interacting with your business
                                                                                        and allows you to connect to many different services to re-sell to your previous customers
                                                                                        and turn prospects into clients.
                                                                                </Col>
                                                                        </Row>
                                                                        <Row>
                                                                                <hr />
                                                                                <Col s={0} m={1}></Col>
                                                                                <Col s={12} m={10}>
                                                                                        <br /><Icon>money_off</Icon>
                                                                                        <br />Spend less money on advertising and staff, target Facebook adverts directly
                                                                                        to the messenger platform and let the bot handle all of the work for your business.
                                                                                        From booking clients into appointments and seminars to making purchases, you can configure
                                                                                        your bot to do what ever helps you the most and save money at the same time!
                                                                                </Col>
                                                                        </Row>
                                                                        <Row>
                                                                                <hr />
                                                                                <Col s={0} m={1}></Col>
                                                                                <Col s={12} m={10}>
                                                                                        <br /><Icon>extension</Icon>
                                                                                        <br />Highly extensible, intergrations with key services and if we haven't
                                                                                        got what you want or need yet feel free to ask us and we'll do the best we
                                                                                        can to get it created and running for you.
                                                                                </Col>
                                                                        </Row>
                                                                </Col>
                                        </Row>
                                        <Row>
                                                <Col s={12} m={6} offset="m3">
                                                        <Card actions={[<a href="#learnmore">Learn More</a>]}>
                                                        Harness the power of Facebook now with an ROI of over 300%, 
                                                        the ability to target the audience who really matters to you and 
                                                        in the location you choose and leave the bot to handle the enquries and bookings. 
                                                        Free up the ability to focus your energy where it really matters, your business.
                                                        <br />Try risk free today!
                                                        <br />
                                                        <br />
                                                        </Card>
                                                </Col>
                                        </Row>
                                        <Footer copyrights={<span><Icon>copyright</Icon> 2017 <a href='www.ukjp-design.com'>ukjp-design</a></span>}
                                                links={
                                                <ul>
                                                        <li><a className="grey-text text-lighten-3" href="#!">FAQ's</a></li>
                                                        <li><Modal
                                                                header='Contact Us'
                                                                fixedFooter
                                                                trigger={
                                                                <a className="grey-text text-lighten-3" href="#!">Contact Us</a>
                                                                }>
                                                                Contacting us:</Modal></li>
                                                </ul>
                                                }>
                                                <h5 style={{color:"white"}}>Created with <span style={{color:"red"}}><Icon>favorite</Icon></span></h5>
                                                <span style={{color:"white"}}>If your interested in working with us or connecting your services
                                                <br />with ours please use the contact us section to get in touch</span>
                                        </Footer>
                                </div>;
                }
        }
}


// Renders content on page load
$( ()=>{

        ReactDOM.render(<Application />, $("#react_context")[0]);
});