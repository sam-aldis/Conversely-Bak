var packageURLS = "botpackages/";
var canvWidth = document.getElementById().width;
var canvHeight = document.getElementById().height;

function parsePackages(packageData) {
    addMenuObject(packageData);
    
}

function loadPackages() {
    $.getJSON(packageURLS + "packages.json").done(function(config) { 
    try {
        for(i in config) {
            $.getJSON(packageURLS + config[i]).done(
                function(data) {
                    parsePackages(data);
                }
            )    
        }
    } catch(e){
        $.getJSON(packageURLS + config).done(
                function(data) {
                    parsePackages(data);
                })
        }
    });
}

$(function() {
    setInitialCanvas();
    loadPackages();
    window.onresize = function() {
        windowSizeChanged();
    }
})