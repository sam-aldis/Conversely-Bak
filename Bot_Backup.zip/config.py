BOT_AUTH_TOKEN = "cd0127d5023fac0612f6c1e53c132f36"
URL = "https://ukjp-design.com:4040/crm"