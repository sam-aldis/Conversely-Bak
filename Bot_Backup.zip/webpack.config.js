'use strict'

var path = require('path');
var webpack = require('webpack');

module.exports = {
    entry :{ 
       botconfig: [
        "./app/index.js", "./app/index.tsx", "./app/index.scss", "./app/assets/sass/materialize.scss", "./app/assets/js/materialize.js"
    ],
    },
    output : {
        path : __dirname + "/dist",
        filename : "index.js"
    },
    resolve : { 
        alias: {
            react: path.resolve(__dirname, './node_modules/react'),
            React: path.resolve(__dirname, './node_modules/react')
        },
        modules : ["node_modules","app"],
        extensions : [".jsx",".js",".html",".png",".jpg",".tsx",".ts",".d.ts",".css",".json",".scss",".woff",".woff2"]
    },
    module :{
        loaders : [
            {
                test : /\.tsx$/,
                loader : "ts-loader?" + JSON.stringify({transpileOnly:true}) 
            },
            {
                test : /\.css$/,
                loader : "style-loader!css-loader"
            },
            {
                test : /\.xhtml$/,
                loader : "html-loader"
            },
            {
                test: /\.wof.*$/,
                loader : 'url-loader?mimetype=application/font-woff'
            },
            {
                test: /\.png$/,
                loader : 'url-loader?mimetype=image/png'
            },
            {
                test : /\.scss$/,
                loaders: ['style-loader','css-loader', 'sass-loader']
            }
        ]
    },
    plugins :[
    //new webpack.optimize.CommonsChunkPlugin({ name: 'commons', filename: 'commons.js', minChunks: 2,}),
  ]
}