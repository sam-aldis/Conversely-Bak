var menuObjects = [];
var logicObjects = [];
var buttonSize = {
    width : 120,
    height: 60
}
var currentDraggedObject;
var currentSelectedObject;
var stage, background, topBar, bottomBar, bottomBarText;
var normalShadow = new createjs.Shadow("#000000", 0, 0, 10);
var selectedShadow = new createjs.Shadow("#FFFFFF",0,0,10);

function setInitialCanvas() {
    // Get the canvas and set dimentions
    canvas = document.getElementById("logicCanvas");
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    stage = new createjs.Stage("logicCanvas");
    stage.enableMouseOver(10);
    // Create the canvas background
    background = new createjs.Shape();
    background.graphics.beginFill("#405261").drawRect(0,0,window.innerWidth,window.innerHeight);
    background.addEventListener("mousedown", deselectAll);
    // Create top bar and children
    topBar = new createjs.Container();
    topBarBackground = new createjs.Shape();
    topBarBackground.graphics.beginFill("#1B1B3A").drawRect(0,0,window.innerWidth,60);
    topBar.addChild(topBarBackground)
    // Create bottom bar and children
    bottomBar = new createjs.Container();
    bottomBar.x = 0;
    bottomBar.y = window.innerHeight - 60;
    bottomBarBackground = new createjs.Shape();
    bottomBarBackground.graphics.beginFill("#0A0908").drawRect(0, 0, window.innerWidth,60);
    bottomBarText = new createjs.Text("","15px Arial","#ffffff")
    bottomBarText.x = 5;
    bottomBarText.y = 5;
    bottomBarText.name = "descriptionText"
    bottomBar.addChild(bottomBarBackground);
    bottomBar.addChild(bottomBarText);
    // Add all elements to the stage
    stage.addChild(background);
    stage.addChild(topBar);
    stage.addChild(bottomBar);
    stage.update();
    createjs.Ticker.addEventListener("tick",tick);
}

function highlightButton(event) {
    target = event.currentTarget.children[0];
    target.graphics.clear().beginFill("#1F1F42").drawRect(target.x,target.y,buttonSize.width,buttonSize.height);
    description = event.currentTarget.data.description;
    bottomBar.getChildByName("descriptionText").text = description;
    stage.update();
}
function unhighlightButton(event) {
    target = event.currentTarget.children[0];
    bottomBar.getChildByName("descriptionText").text = "";
    target.graphics.clear().beginFill("#1B1B3A").drawRect(target.x,target.y,buttonSize.width,buttonSize.height);
    stage.update();
}
function buttonDragged(event) {
    currentDraggedObject.x = event.stageX;
    currentDraggedObject.y = event.stageY;
    stage.update();
}

function parseCanvasObject(canvasObject) {
    let container = new createjs.Container()
    container.x = 50;
    container.y = 80;
    let localObjects = [];
    // Create the children for the container
    for(i in canvasObject.children) {
        let curItem = canvasObject.children[i]
        if(curItem.shape == "rect") {
            localObjects.push(new createjs.Shape())
            localObjects[i].graphics.beginFill(curItem.color).beginStroke("white").drawRect(0,0,curItem.size.width,curItem.size.height);
            container.addChild(localObjects[i])
        }
        if(curItem.shape == "text") {
            localObjects.push(new createjs.Text(curItem.text, curItem.size + " Arial",curItem.color))
            localObjects[i].x = curItem.offset.x;
            localObjects[i].y = curItem.offset.y;
            container.addChild(localObjects[i])
        }
    }
    // Create the inlets and outlets for the container logic
    return container;
}

function windowSizeChanged() {
    setInitialCanvas();
    loadPackages();
}


function createDraggedObject(target) {
    container = parseCanvasObject(target.data.canvasObject);
    container.addEventListener("pressmove", dragObject);
    container.addEventListener("click",selectObject);
    container.objectnumber = logicObjects.length;
    container.shadow = normalShadow;
    logicObjects.push(container)
    stage.addChild(container)
    stage.update()
    return container
}
function startDrag(event) {
    currentDraggedObject = createDraggedObject(event.target.parent)
}
function addMenuObject(objectData) {
    if(menuObjects.length != 0) {
        lastMenuItem = menuObjects[menuObjects.length - 1]
        startX = lastMenuItem.x + buttonSize.width
        console.log(startX)
        startY = 0;
    } else {
        startX = 0;
        startY = 0;
    }
    let text = objectData.menuObject.text;
    let menuButton = new createjs.Container();
    menuButton.x = startX;
    menuButton.y = startY;
    menuButton.cursor = "pointer";
    menuButton.addEventListener("mouseover",highlightButton);
    menuButton.addEventListener("mouseout",unhighlightButton);
    menuButton.addEventListener("mousedown",startDrag);
    menuButton.addEventListener("pressmove",buttonDragged)
    menuBackground = new createjs.Shape();
    menuBackground.graphics.beginFill("#1B1B3A").drawRect(startX,startY,buttonSize.width,buttonSize.height);
    menuText = new createjs.Text(text, "20px Arial", "#ffffff");
    menuText.y = 20;
    menuText.x = 10;
    menuButton.name = text;
    menuButton.addChild(menuBackground);
    menuButton.addChild(menuText);
    menuButton.data = objectData;
    menuObjects.push(menuButton);
    stage.addChild(menuButton);
    stage.update();
}
function deselectAll(event) {
    currentSelectedObject = 0;
}
function checkSelectedItem(){
    if(currentSelectedObject != null) {
        currentSelectedObject.shadow = selectedShadow;
        objectno = currentSelectedObject.objectnumber;
        for(i in logicObjects) {
            if(logicObjects[i].objectnumber != objectno){
                logicObjects[i].shadow = normalShadow;
            }
        }
    }
}
function tick(){
    checkSelectedItem();
    stage.update();
}
function selectObject(event) {
    currentSelectedObject = event.currentTarget;
    event.currentTarget.shadow = selectedShadow;
    stage.update()
}
// function to drag the currently selected object around the canvas
function dragObject(event) {
    currentSelectedObject = event.currentTarget
    event.currentTarget.shadow = selectedShadow;
    event.currentTarget.x = event.stageX;
    event.currentTarget.y = event.stageY;
    stage.update();
}
