import tornado.web
import tornado.httpclient
import pymongo
import datetime, pytz
from ukjp import login, database

class FacebookBotHandler(tornado.web.RequestHandler):
    def get(self):
        Login = login.Login()
        if Login.checkCookie(self):
            self.render("facebookconfigure.html")
        
    def post(self):
        return 1

def dataImportHandler(location):
    dbcon = pymongo.MongoClient()
    db = dbcon[location]
    cur = db.facebookbot
    ret = cur.find({})
    for i in ret:
        try:
            database.addToMasterDatabase(i)
        except:
            pass
    today = datetime.datetime.now(pytz.timezone("Australia/Perth")).date()
    yesterday = today.toordinal() - 1
    ret = cur.find({"date_ordinal": {"$gt":yesterday}}).sort([("date_ordinal",pymongo.ASCENDING),("appointment_time",pymongo.ASCENDING)])
    for i in ret:
        database.addAppointment(i)

def getBotStatus():
    cli = tornado.httpclient.HTTPClient()
    url = config.URL + "?auth_token=" + config.BOT_AUTH_TOKEN + "&type=status" 
    data = cli.fetch(url)
    return data.body

def getData():
    return 1

def getDash(location):
    return "<div class=''>Bot Status: " + str(getBotStatus()) + "</div>"


urlhandler = tornado.web.url(r"/facebookbot", FacebookBotHandler)